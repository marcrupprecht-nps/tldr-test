# pwd

> CLI-Ausgabe des aktuellen Arbeitsverzeichnisses. *pwd* steht für "present working directory".

- Ausgabe des akutellen Arbeitsverzeichnisses:
  `pwd`
